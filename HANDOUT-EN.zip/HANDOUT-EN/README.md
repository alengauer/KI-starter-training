# AI Support for Efficient Quality Assurance and Smart Software Testing

Handout for the two-day in-house classroom training on using generative AI in test analysis, test management and quality assurance.

This is the English edition. The German original is in the [HANDOUT](../HANDOUT) folder.

The training offers a first introduction to the topic: what a language model does, how to use it sensibly in a testing context, how to evaluate its results and what to consider legally. No prior knowledge of AI or programming is required.

**Guiding principle:** The AI generates quickly, the human checks deliberately. Every generated result is reviewed before it is used further.

## Contents of this folder

### Slide decks

| File | Topic |
|---|---|
| [Module-0_Introduction.pdf](Module-0_Introduction.pdf) | Introduction, goals and schedule |
| [Module-1_Fundamentals-and-Key-Terms.pdf](Module-1_Fundamentals-and-Key-Terms.pdf) | AI, machine learning, generative AI; how a language model answers; variation and plausible errors; prompt, context, RAG, agent |
| [Module-2_Working-with-the-Model.pdf](Module-2_Working-with-the-Model.pdf) | Effective prompts for QA tasks, iterative improvement, surfacing assumptions, skills |
| [Module-3_Potential-and-Limits-in-Software-Testing.pdf](Module-3_Potential-and-Limits-in-Software-Testing.pdf) | Use cases along the test process, realistic expectations, reviewing requirements |
| [Module-4_AI-Assisted-Test-Case-Creation-Focus.pdf](Module-4_AI-Assisted-Test-Case-Creation-Focus.pdf) | **Focus:** test cases from user stories with equivalence partitioning, boundary value analysis, decision tables and state transitions |
| [Module-5_Integration-into-Existing-Test-Processes.pdf](Module-5_Integration-into-Existing-Test-Processes.pdf) | From model output to usable artifact, Gherkin, the path into the test management tool |
| [Module-6_Evaluating-Results.pdf](Module-6_Evaluating-Results.pdf) | Evaluating AI-generated test artifacts, error patterns, source references and confidence, cross-checking |
| [Module-7_Legal-Framework.pdf](Module-7_Legal-Framework.pdf) | Legal aspects, in particular the EU AI Act |
| [Module-8_Suitability-for-Your-Own-Projects.pdf](Module-8_Suitability-for-Your-Own-Projects.pdf) | Criteria for selecting AI tools for your own test process |

### Working materials

| File | Contents |
|---|---|
| [Participant-Workbook.pdf](Participant-Workbook.pdf) | Exercise instructions with ready-to-copy prompts, requirement texts for the case study (Appendix A) and templates (Appendix B): review log, SKILL.md, evaluation matrix for AI tools, labelling of AI-assisted artifacts |
| [Solutions-Booklet.pdf](Solutions-Booklet.pdf) | Solution outlines, solution keys, typical mistakes and discussion points for all exercises. For the best learning effect, read only after the respective exercise. |
| [Prompt-Collection.pdf](Prompt-Collection.pdf) | 25 reusable prompt templates for work after the course: reviewing requirements, test design, test data, Gherkin, cross-checking, defect reports, surfacing assumptions, skills |
| [OpenWebUI-Demos-Testing.md](OpenWebUI-Demos-Testing.md) · [PDF](OpenWebUI-Demos-Testing.pdf) | Ten hands-on demos in the chat (no file upload), each with the complete prompt and the weakness it reveals |

### Case study

The sample project **SneakerStudio** of the fictitious company Schnürschuh & Collegen GmbH is available only in the German folder as [sneakerstudio.zip](../HANDOUT/sneakerstudio.zip). It is a web app for customer account creation, password management, account activation and sign-in, and contains use case documentation, feature specifications, source code with unit and E2E tests, and a Claude Code configuration with skills, hooks and a subagent for test design. Entry points: `README.md` and `Demo.md` in the archive.

The archive is unchanged, so its documentation and the app's user interface are in German. Code examples on the slides that quote UI texts therefore keep the German strings.

## Exercises at a glance

| Exercise | Topic |
|---|---|
| Mini exercise | Experiencing variation |
| 1 | From a weak to a strong prompt |
| 1b | Writing your own skill |
| 2 | Reviewing requirements |
| 3a | Equivalence partitions and boundary values |
| 3b | Decision table |
| 3c | State transitions |
| 4 | Converting test cases into Gherkin |
| 5 | Finding errors in an AI artifact |
| 6 | Evaluating your own use case |
| Extra | The human as harness |

All exercises work simply by pasting text into a chat, without administrator rights and without file upload.

## Notes

- **Results vary.** Answers from language models differ by model, system prompt and run. Your own result may deviate from the solution key and still be correct; what matters is whether every statement traces back to a passage in the requirement.
- **Legal status.** The content on the legal framework reflects the status at the time of the training. The legal situation evolves quickly and must be checked before you rely on it.
- **Case study and data.** SneakerStudio and Schnürschuh & Collegen GmbH are fictitious; all test data is synthetic.
- **Translation.** This edition is a translation of the German handout. Slide numbers match the German decks.

## Author

Trainer: Andreas Lengauer · Status: November 2026
